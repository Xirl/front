# vue项目

效果：

 [http://36.139.159.39:9090/](http://36.139.159.39:9090/) 访问网站出现数据

流程：

 本地修改代码-->提交到svn仓库-->jenkins拉取svn代码进行编译构建，启动nodejs后端服务，并把dist资源发送到nginx服务器，由容器内的nginx展示

环境：

本地电脑安装nodejs、npm、vue、svn或git、Visual Studio

两台服务器：

120.79.205.221 安装nodejs、npm、jenkins、svn或git

36.139.159.39  安装docker、nginx镜像

步骤：

一、安装本地环境

**svn安装**

使用svnbucket教程安装  [https://svnbucket.com/](https://svnbucket.com/)

![image](assets/image-20221028170131-c0eqkt5.png)

下拉下载汉化包

![image](assets/image-20221028170231-g6mndl9.png)​

svnbucket 创建仓库

本地创建文件夹上传或checkout下载项目

**nodejs和npm安装**

https://www.cnblogs.com/stcweb/articles/15585559.html

**Visual Studio安装**

**项目****使用学习视频**

[vue项目和nodejs项目部署实战 nginx+docker持续集成_哔哩哔哩_bilibili](https://www.bilibili.com/video/BV1u3411r7dp/?spm_id_from=333.337.search-card.all.click&vd_source=21be2dd854a9884407dab4935b7c55e7)

项目代码

[https://github.com/sillyhong/whongjiagou-learn/blob/master/turndownMarkdown/markdown/72.deploy.md](https://github.com/sillyhong/whongjiagou-learn/blob/master/turndownMarkdown/markdown/72.deploy.md)

‍

> **window命令行操作**
>
> 下载vue的时候太慢，可以配置淘宝源，使用cnpm  
> npm config set registry https://registry.npm.taobao.org  
> 检查是否下载成功  
> npm config get registry
>
> 安装vue脚手架程序vue-cli  
> // 安装  
> npm install -g @vue/cli  
> // 或者  
> cnpm install -g @vue/cli  
> // 或者  
> yarn global add @vue/cli
>
> 卸载 npm uninstall vue-cli -g
>

1、新建项目目录

 E:\testv<br />testv下创建目录存放后端代码  
 E:\testv\back

当前目录下Shift+右键，选powershell窗口 或  路径上搜cmd，打开命令行

![image](assets/image-20221028173845-m0uynxw.png)

自动创建并初始化项目：

命令行输入 cnpm init -y

visual studio打开back文件夹，新建server.js文件

```js
let http = require('http');
let users = [{id:58,name:'zhufeng1'},{id:31,name:'zhufeng2'},{id:3,name:'zhufeng3'}];
let server = http.createServer(function(req,res){
  console.log(req.method,req.url);
  if(req.url == '/api/users'){
    res.setHeader('Access-Control-Allow-Origin','*');
    res.end(JSON.stringify(users));
  }else{
    res.end('Now Found!');
  }
});
server.listen(3000,()=>{
  console.log('服务正在3000端口上启动!');
});
```

pakeage.json

```json
{
  "name": "back",
  "version": "0.0.0",
  "private": true,
  "scripts": {
    "start": "node ./server.js "
  }
}
```

安装和npm差不多的yarn包管理器  
npm install -g yarn

回到testv文件夹下，命令行输入，（需要选择vue框架版本，vue2就行）之后会自动创建前端项目文件夹

vue create vue-front

完成后启动服务  
yarn serve

vue-front下新增后端接口  
yarn add axios

visual studio打开front文件夹，修改APP.vue文件

```js
<template>
  <ul>
    <li v-for="(user) in users" :key="user.id">
      {{user.id}}:{{user.name}}
    </li>
  </ul>
</template>
<script>
import axios from 'axios';
export default {
  name: 'app',
  data(){
    return {
      users:[]
    }
  },
  mounted(){
      axios.get('http://120.79.205.221:3000/api/users').then(response=>{
      this.users = response.data;
    });
  }
}
</script>
<style>
</style>
```

svn提交更新

二、120.79.205.221 服务器环境

**jenkins自由任务的配置**

表示从svn仓库拉取代码到jenkins的工作空间目录下，进行编译，然后将编译结果发送到nginx 服务器

![image](assets/image-20221028180837-hs95s8s.png)​

构建编译vue前端代码，会生成dist文件夹，文件夹直接扔到nignx的usr/share/nginx/html下，网站就可以运行了

![image](assets/image-20221028234853-pzbyx37.png)

安装pm2管理node进程工具

```bash
使用node server.js 会阻塞前台，无法进行其他操作，故用pm2
npm install pm2 -g    #全局安装pm2
pm2 start back/server.js     #启动服务器
pm2 list              #查看运行状态
pm2 logs              #查看日志
pm2 restart www       #重启应用
pm2 stop www          #停止应用
```

![image](assets/image-20221028215926-gyxecay.png)​

```bash
Source files填写错误会导致SSH: Transferred 0 file(s)
填 front/dist      无法拷贝
填 front/dist/*    则dist下的子目录不会拷贝，只会拷贝dist下层的文件
填 front/dist/**   则dist下的文件和目录均会被拷贝

文件传输完成后需要执行把容器内nginx的html目录下的文件改为nginx属主，这样才不会报403访问拒绝,html下没文件也会报403
```

Source填写以工作空间目录作为/根开始

![image](assets/image-20221028212908-r7oc7wf.png)

**启动nodejs的后端server**

```bash
进入文件夹
.jenkins/workspace/testv/back
执行启动命令
node server.js

此实验不需要启动前端服务
#front里前端vue项目启动用命令 npm run serve 或 yarn serve
```

三、36.139.159.39服务器

安装docker[^1]

```bash
启动nginx的时候把html目录挂载出来
docker run -di --name=mynginx -p 9090:80 -v /root/data/dist:/usr/share/nginx/html nginx
```

实验效果访问nginx，前端代码里指定了去访问后端的网站http://120.79.205.221:3000/api/users获取数据，然后再把数据填充回前端页面

![image](assets/image-20221028221124-x2ekp1l.png)​

[^1]: ### 安装 docker

    Docker部署[^2]  
    yum  -y  install yum-utils  
    yum-config-manager  --add-repo  https://download.docker.com/linux/centos/docker-ce.repo          \#添加下载仓库  
    yum  install -y docker-ce  docker-ce-cli  containerd.io           \#安装发行版 docker、客户端命令行、容器相关组件  
    systemctl enable docker  --now      \#开机自启 + 现在马上启动  
    由于 docker hub 是外国网站，pull 较慢，可以配置阿里容器镜像加速器

    进入云服务器控制台-->搜容器镜像服务-->选镜像工具

    ```bash
    mkdir -p  /etc/docker
    #镜像仓库配置，1、阿里云镜像加速器，最好用阿里的
    tee  /etc/docker/daemon.json  <<- 'EOF'
    {
     "registry-mirrors": ["https://82m9ar63.mirror.aliyuncs.com"],          #此网址必须在自己的阿里云控制台-容器镜像服务找到
     "exec-opts": ["native.cgroupdriver=systemd"],
     "log-driver": "json file",
     "log-opts": { "max-size": "100m"},
     "storage-driver": "overlay2"
    }
    EOF
    #或者2、
    tee  /etc/docker/daemon.json  <<- 'EOF'
    {
     "registry-mirrors": ["https://docker.mirrors.ustc.edu.cn"]
    }
    EOF
    ##
    Docker 中国官方镜像 	https://registry.docker-cn.com
    DaoCloud 镜像站 	http://f1361db2.m.daocloud.io
    Azure 中国镜像 	https://dockerhub.azk8s.cn
    科大镜像站 	https://docker.mirrors.ustc.edu.cn
    阿里云 	https://<your_code>.mirror.aliyuncs.com
    七牛云 	https://reg-mirror.qiniu.com
    网易云 	https://hub-mirror.c.163.com
    腾讯云 	https://mirror.ccs.tencentyun.com

    systemctl daemon-reload
    systemctl restart docker

    ```

    ‍

    ---


[^2]: ## Docker部署

    1、yum包更新到最新

    > yum update
    >

    2、安装需要的软件包，yum-util提供yum-config-manager功能，另外两个是devicemapper驱动依赖的

    > yum install -y yum-utils devmapper-persistent-data 1vm2
    >

    3、设置yum源为阿里云

    > yum-config-manager --add-repo http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
    >

    4、安装docker

    > yum -y install docker-ce
    >
